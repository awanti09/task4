package com.example.task4

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    @SuppressLint("WrongViewCast", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val friends = findViewById<TextView>(R.id.friends)
        friends.setOnClickListener {
            val intent = Intent(this, Groups::class.java)
            startActivity(intent)
        }

        val addbutton = findViewById<ImageView>(R.id.addbutton)
        addbutton.setOnClickListener {
            val intent = Intent(this, Add::class.java)
            startActivity(intent)
        }
    }
    }

